These JSON payloads are of the respective Create or Cancel types	
	EiCreateTender
	EiCreateTransaction
	EiCancelTender
	
Paste into Postman for the correct URI. The responses are correct and of the correct types	
	EiCreatedTender
	EiCreatedTransaction
	EiCanceldTender
	
Yes, adding a "d" in the middle is bad identifer design but see the standards for why...	
	
I copy a cell from the Excel spreadsheet and paste into Postman's Body window (raw JSON) and hit Send.

URIs that work are in the separate URI layout document.
